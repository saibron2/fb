import pygame
import sys
from pygame.color import THECOLORS

from trak import Track

class Main:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((400, 800))
        self.track = Track()

    def draw(self):
        self.track.draw(self.screen)

    def start(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
            self.draw()
            pygame.display.flip()

main = Main()
main.start()