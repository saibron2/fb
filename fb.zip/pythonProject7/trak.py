import pygame

class Track:
    def __init__(self):
        self.image = pygame.image.load(r'C:\Users\movavi_school\Desktop\pythonProject7\img\bird.png')

    def draw(self, screen):
        screen.blit(self.image, (250, 500))